import React, { useEffect, useMemo, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { Play, Pause, RotateCcw, Flame, SlidersHorizontal, Github } from 'lucide-react'

const DEFAULTS = {
  width: 72,
  height: 42,
  ambientTemp: 20,
  sourcePower: 220,
  sourceRadius: 3.4,
  sourceSpeed: 16,
  conductivity: 0.16,
  cooling: 0.012,
  timeStep: 0.12,
  fps: 30,
}

const clamp = (value, min, max) => Math.min(max, Math.max(min, value))
const gridIndex = (x, y, width) => y * width + x
const createGrid = (width, height, fill) => {
  const arr = new Float32Array(width * height)
  arr.fill(fill)
  return arr
}

const formatNumber = (value, digits = 1) => (Number.isFinite(value) ? value.toFixed(digits) : '0.0')

function colorForTemperature(temp, minT, maxT) {
  const range = Math.max(1, maxT - minT)
  const t = clamp((temp - minT) / range, 0, 1)

  const r = Math.round(255 * Math.min(1, Math.max(0, 1.5 * t)))
  const g = Math.round(255 * Math.min(1, Math.max(0, 1.5 * (1 - Math.abs(t - 0.5) * 2))))
  const b = Math.round(255 * Math.min(1, Math.max(0, 1.4 * (1 - t))))

  return `rgb(${r}, ${g}, ${b})`
}

export default function App() {
  const [params, setParams] = useState(DEFAULTS)
  const [running, setRunning] = useState(false)
  const [simulationTime, setSimulationTime] = useState(0)
  const [temperature, setTemperature] = useState(() => createGrid(DEFAULTS.width, DEFAULTS.height, DEFAULTS.ambientTemp))
  const [peakTemp, setPeakTemp] = useState(DEFAULTS.ambientTemp)
  const [currentMaxTemp, setCurrentMaxTemp] = useState(DEFAULTS.ambientTemp)

  const canvasRef = useRef(null)
  const animationRef = useRef(null)
  const accumulatorRef = useRef(0)
  const lastFrameRef = useRef(0)

  const sourcePosition = useMemo(() => {
    const startX = 4
    const x = (startX + simulationTime * params.sourceSpeed) % (params.width + 8) - 4
    const y = Math.floor(params.height / 2)
    return { x, y }
  }, [simulationTime, params.width, params.height, params.sourceSpeed])

  const gridSize = useMemo(() => params.width * params.height, [params.width, params.height])

  const resetSimulation = (customParams = params) => {
    setRunning(false)
    setSimulationTime(0)
    setTemperature(createGrid(customParams.width, customParams.height, customParams.ambientTemp))
    setPeakTemp(customParams.ambientTemp)
    setCurrentMaxTemp(customParams.ambientTemp)
    accumulatorRef.current = 0
    lastFrameRef.current = 0
  }

  const updateParam = (key, value) => {
    setParams((prev) => ({ ...prev, [key]: value }))
  }

  useEffect(() => {
    resetSimulation(params)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.width, params.height, params.ambientTemp])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    const cellSize = Math.max(8, Math.floor(720 / params.width))
    canvas.width = params.width * cellSize
    canvas.height = params.height * cellSize

    let minT = params.ambientTemp
    let maxT = params.ambientTemp
    for (let i = 0; i < temperature.length; i += 1) {
      const t = temperature[i]
      if (t < minT) minT = t
      if (t > maxT) maxT = t
    }

    for (let y = 0; y < params.height; y += 1) {
      for (let x = 0; x < params.width; x += 1) {
        const t = temperature[gridIndex(x, y, params.width)]
        ctx.fillStyle = colorForTemperature(t, minT, maxT)
        ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize)
      }
    }

    const srcPixelX = sourcePosition.x * cellSize
    const srcPixelY = sourcePosition.y * cellSize
    ctx.strokeStyle = 'rgba(255,255,255,0.95)'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.arc(srcPixelX, srcPixelY, Math.max(4, params.sourceRadius * cellSize), 0, Math.PI * 2)
    ctx.stroke()
  }, [temperature, params, sourcePosition])

  useEffect(() => {
    if (!running) {
      if (animationRef.current) cancelAnimationFrame(animationRef.current)
      animationRef.current = null
      return
    }

    const frameInterval = 1000 / params.fps

    const stepSimulation = () => {
      setTemperature((prev) => {
        const next = new Float32Array(gridSize)
        const w = params.width
        const h = params.height
        const ambient = params.ambientTemp
        const alpha = params.conductivity
        const cooling = params.cooling
        const dt = params.timeStep
        const radiusSq = Math.max(0.001, params.sourceRadius * params.sourceRadius)

        let localMax = ambient

        for (let y = 0; y < h; y += 1) {
          for (let x = 0; x < w; x += 1) {
            const i = gridIndex(x, y, w)
            const center = prev[i]
            const left = prev[gridIndex(Math.max(0, x - 1), y, w)]
            const right = prev[gridIndex(Math.min(w - 1, x + 1), y, w)]
            const up = prev[gridIndex(x, Math.max(0, y - 1), w)]
            const down = prev[gridIndex(x, Math.min(h - 1, y + 1), w)]

            const laplacian = left + right + up + down - 4 * center
            const dx = x - sourcePosition.x
            const dy = y - sourcePosition.y
            const distanceSq = dx * dx + dy * dy
            const heatInput = params.sourcePower * Math.exp(-distanceSq / (2 * radiusSq))
            const coolingLoss = cooling * (center - ambient)
            const nextTemp = center + dt * (alpha * laplacian + heatInput - coolingLoss)

            next[i] = Math.max(ambient, nextTemp)
            if (next[i] > localMax) localMax = next[i]
          }
        }

        setCurrentMaxTemp(localMax)
        setPeakTemp((prevPeak) => Math.max(prevPeak, localMax))
        return next
      })

      setSimulationTime((prev) => prev + params.timeStep)
    }

    const animate = (timestamp) => {
      if (!lastFrameRef.current) lastFrameRef.current = timestamp
      const delta = timestamp - lastFrameRef.current
      lastFrameRef.current = timestamp
      accumulatorRef.current += delta

      while (accumulatorRef.current >= frameInterval) {
        stepSimulation()
        accumulatorRef.current -= frameInterval
      }

      animationRef.current = requestAnimationFrame(animate)
    }

    animationRef.current = requestAnimationFrame(animate)

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }
  }, [running, params, gridSize, sourcePosition.x, sourcePosition.y])

  const avgTemp = useMemo(() => {
    let sum = 0
    for (let i = 0; i < temperature.length; i += 1) sum += temperature[i]
    return sum / Math.max(1, temperature.length)
  }, [temperature])

  return (
    <div className="page-shell">
      <div className="container">
        <motion.section
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45 }}
          className="hero"
        >
          <div className="hero-left card">
            <div className="title-row">
              <Flame className="icon-lg" />
              <div>
                <h1>Модель изменения температуры при наплавке</h1>
                <p>
                  Готовый сайт для GitHub Pages: интерактивная тепловая карта, движущийся источник тепла и настройка параметров прямо в браузере.
                </p>
              </div>
            </div>

            <div className="stats-grid">
              <StatCard label="Время моделирования" value={`${formatNumber(simulationTime, 2)} с`} />
              <StatCard label="Текущий максимум" value={`${formatNumber(currentMaxTemp, 1)} °C`} />
              <StatCard label="Пиковая температура" value={`${formatNumber(peakTemp, 1)} °C`} />
              <StatCard label="Средняя температура" value={`${formatNumber(avgTemp, 1)} °C`} />
            </div>
          </div>

          <div className="hero-right card">
            <div className="title-row compact">
              <SlidersHorizontal className="icon-md" />
              <h2>Управление</h2>
            </div>
            <div className="button-grid">
              <button className="btn btn-primary" onClick={() => setRunning((prev) => !prev)}>
                {running ? <Pause size={18} /> : <Play size={18} />}
                {running ? 'Пауза' : 'Старт'}
              </button>
              <button className="btn btn-secondary" onClick={() => resetSimulation()}>
                <RotateCcw size={18} />
                Сброс
              </button>
              <button
                className="btn btn-ghost"
                onClick={() => {
                  setParams(DEFAULTS)
                  resetSimulation(DEFAULTS)
                }}
              >
                По умолчанию
              </button>
            </div>
            <div className="hint-box">
              Белый круг показывает положение источника тепла. Яркие цвета на карте означают более высокую температуру.
            </div>
            <a
              className="github-link"
              href="https://github.com/new"
              target="_blank"
              rel="noreferrer"
            >
              <Github size={18} />
              Создать новый репозиторий на GitHub
            </a>
          </div>
        </motion.section>

        <section className="content-grid">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.08 }}
            className="card"
          >
            <h2 className="section-title">Тепловая карта</h2>
            <div className="canvas-frame">
              <canvas ref={canvasRef} className="canvas" />
            </div>

            <div className="stats-grid compact-grid">
              <StatCard label="Позиция источника X" value={formatNumber(sourcePosition.x, 1)} />
              <StatCard label="Ширина сетки" value={String(params.width)} />
              <StatCard label="Высота сетки" value={String(params.height)} />
              <StatCard label="Шаг времени" value={`${formatNumber(params.timeStep, 2)} с`} />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.14 }}
            className="card"
          >
            <h2 className="section-title">Параметры процесса</h2>
            <div className="control-list">
              <SliderControl label="Температура среды" value={params.ambientTemp} min={0} max={100} step={1} suffix="°C" onChange={(v) => updateParam('ambientTemp', v)} />
              <SliderControl label="Мощность источника" value={params.sourcePower} min={20} max={500} step={1} suffix="усл. ед." onChange={(v) => updateParam('sourcePower', v)} />
              <SliderControl label="Радиус источника" value={params.sourceRadius} min={1} max={8} step={0.1} suffix="клетки" onChange={(v) => updateParam('sourceRadius', v)} />
              <SliderControl label="Скорость наплавки" value={params.sourceSpeed} min={2} max={30} step={0.5} suffix="клет/с" onChange={(v) => updateParam('sourceSpeed', v)} />
              <SliderControl label="Теплопроводность" value={params.conductivity} min={0.01} max={0.5} step={0.01} suffix="" onChange={(v) => updateParam('conductivity', v)} />
              <SliderControl label="Охлаждение" value={params.cooling} min={0} max={0.08} step={0.001} suffix="" onChange={(v) => updateParam('cooling', v)} />
              <SliderControl label="Шаг по времени" value={params.timeStep} min={0.02} max={0.4} step={0.01} suffix="с" onChange={(v) => updateParam('timeStep', v)} />

              <div className="number-grid">
                <NumberControl label="Ширина сетки" value={params.width} min={24} max={140} onChange={(v) => updateParam('width', clamp(v, 24, 140))} />
                <NumberControl label="Высота сетки" value={params.height} min={20} max={90} onChange={(v) => updateParam('height', clamp(v, 20, 90))} />
              </div>
            </div>
          </motion.div>
        </section>
      </div>
    </div>
  )
}

function StatCard({ label, value }) {
  return (
    <div className="stat-card">
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
    </div>
  )
}

function SliderControl({ label, value, min, max, step, suffix, onChange }) {
  return (
    <div className="control-group">
      <div className="control-header">
        <label>{label}</label>
        <span>
          {formatNumber(value, step < 1 ? 2 : 0)} {suffix}
        </span>
      </div>
      <input
        className="slider"
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </div>
  )
}

function NumberControl({ label, value, min, max, onChange }) {
  return (
    <div className="control-group">
      <label>{label}</label>
      <input
        className="number-input"
        type="number"
        min={min}
        max={max}
        value={value}
        onChange={(e) => {
          const next = Number(e.target.value)
          if (!Number.isNaN(next)) onChange(next)
        }}
      />
    </div>
  )
}
